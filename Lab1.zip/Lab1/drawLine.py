from turtle import*
from random import*

def drawLine(p):
    forward(p)
    done()
    
print(drawLine(100))
from turtle import*
from random import*

def drawLine(p):
    
    x = random()*276
    forward(x)
    done()
    
print(drawLine(100))
from turtle import*
from random import*

def drawTriangle(p):
    
    x = random()*302
    forward(x)
    up()
    left(120)
    down()
    forward(x)
    up()
    left(120)
    down()
    forward(x)
    done()
    
print(drawTriangle(100))
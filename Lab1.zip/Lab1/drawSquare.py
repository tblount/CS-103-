from turtle import*
from random import*

def drawSquare(p):

    for i in range(4):
        forward(p)
        up()
        left(90)
        down()
        forward(p)
    done()

print(drawSquare(100))
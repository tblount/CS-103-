from turtle import*
from random import*

def drawSquare(p):

    for i in range(4):
        x = random()*250
        forward(x)
        up()
        left(90)
        down()
        forward(x)
    done()

print(drawSquare(100))